const fs = require('fs');
const net = require('net');

const PORT = 5000;
const FILE_PATH = 'share.mp4'; // Update with your file path

const server = net.createServer((socket) => {
  console.log('Client connected:', socket.remoteAddress, socket.remotePort);
  const fileStream = fs.createReadStream(FILE_PATH);

  fileStream.on('data', (data) => {
    socket.write(data);
  });

  fileStream.on('end', () => {
    console.log('File sent successfully.');
    socket.end();
  });
});

server.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
