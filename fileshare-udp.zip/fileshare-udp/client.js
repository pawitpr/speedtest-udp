const fs = require('fs');
const net = require('net');
const progress = require('progress');

const PORT = 5000;
const FILE_PATH = 'speedtest.exe'; // Update with your desired file path to save

const fileStream = fs.createWriteStream(FILE_PATH);

const socket = net.connect(PORT, '192.168.211.54', () => {
  console.log('Connected to server.');

  socket.on('data', (data) => {
    fileStream.write(data);
  });

  socket.on('end', () => {
    console.log('File received successfully.');
    fileStream.end();
    socket.destroy();
  });

  // Progress bar
  const fileSize = socket.bytesRead;
  const progressBar = new progress('Downloading [:bar] :percent :etas', {
    complete: '=',
    incomplete: ' ',
    width: 50,
    total: fileSize
  });

  // Speed calculation
  let lastBytesRead = 0;
  setInterval(() => {
    const bytesRead = socket.bytesRead;
    const speed = bytesRead - lastBytesRead;
    lastBytesRead = bytesRead;
    progressBar.tick(speed);
  }, 1000);
});
